export default (sequelize) => {
    // Trả về object rỗng để index.js có thể import default mà không lỗi.
    return {};
};